// column-submit.h

#ifndef COLUMN_SUBMIT_H_
#define COLUMN_SUBMIT_H_

#include <string>
#include <iostream>

/// TODO: Add the definitions of inline global functions below

template <>
inline std::string Column<int>::as_string_at(int index) const {

}

template <>
inline std::string Column<bool>::as_string_at(int index) const {

}

template <>
inline std::string Column<std::string>::as_string_at(int index) const {

}

template <typename T>
inline std::ostream& operator<<(std::ostream& os, const Column<T>& column) {

}

/// TODO: Add the missing function definitions of the Column template below

template <typename T>
void Column<T>::reserve_capacity(int new_capacity) {

}

template <typename T>
void Column<T>::expand_size(int new_size) {

}

template <typename T>
void Column<T>::append(const Column<T>& other) {

}

template <typename T>
const Column<T>& Column<T>::operator=(const Column<T>& other) {

}

template <typename T>
Column<T> Column<T>::operator+(const Column<T>& other) const {

}

template <typename T>
const Column<T>& Column<T>::operator+=(const Column<T>& other) {

}

template <typename T>
Column<bool> Column<T>::operator==(const Column<T>& other) const {

}

template <typename T>
Column<bool> Column<T>::operator<(const Column<T>& other) const {

}

template <typename T>
Column<bool> Column<T>::operator==(const T& other) const {

}

template <typename T>
Column<bool> Column<T>::operator<(const T& other) const {

}

template <typename T>
Column<bool> Column<T>::operator!() const {

}

template <typename T>
Column<bool> Column<T>::operator&&(const Column<T>& other) const {

}


template <typename T>
T Column<T>::operator[](int index) const {

}

template <typename T>
T& Column<T>::operator[](int index) {

}

template <typename T>
Column<T>::Column(const Column<T>& other, const Column<bool>& selector) {

}

template <typename T>
Column<T> Column<T>::operator[](const Column<bool>& selector) const {

}

#endif  // COLUMN_SUBMIT_H_
